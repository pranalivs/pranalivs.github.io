package emailapp;

import java.util.Scanner;

public class Email {

	private String firstName;
	private String lastName;
	private String password;
	private String email;
	private String department;
	private int defaultPasswordLength = 8;
	private int mailboxCapacity = 500;
	private String companyName = "A1Company.com";
	private String alternateEmail;


	//Constructor to receive firstName and lastName
	
	public Email(String firstName, String lastName) {
		this.firstName = firstName;
		this.lastName = lastName;
		
		System.out.println("Name of the Employee is: " + this.firstName + " " +this.lastName);
	
	//Call a method to get department and return the department 
		this.department = setDepartment();
		System.out.println("Department is: " +this.department);
		
	//Call a method to generate a random password
		this.password = randomPassowrd(defaultPasswordLength);
		System.out.println("Your password is: " +this.password);
		
	//Generate an email for company
		
		email = firstName.toLowerCase() + "." + lastName.toLowerCase() + "@"+ department + "." + companyName;
		//System.out.println("Your Email ID is:" +email);
		
	
}
	
	//Ask for department
	private String setDepartment() 
	{
	
	System.out.print("Department Codes Are::\n1. Sales \n2. Developement \n3. Accounting \n4. None \nEnter The Department Code:");
	Scanner in = new Scanner(System.in);
	int depchoice = in.nextInt();
	
	if (depchoice == 1) 
	{	
		return "Sales" ;
	}
	else if (depchoice == 2) 
	{
		return "Developement";
	}
	else if (depchoice == 3) 
	{
		return "Accounting";
	}
	else 
	{
		return "No Department";
	}
	
	}
	
	//Generate random password
	public String randomPassowrd(int length) 
	{
		String passwordSet ="ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789!@#$%";
		char[] password = new char[length];
		for(int i=0; i<length; i++)
		{
			int rand = (int) (Math.random() *passwordSet.length());
			password[i] = passwordSet.charAt(rand);
			
		}
		
		return new String(password);
	}
	
	//Set the mailbox capacity
	public void setMailboxCapacity(int capacity) {
		this.mailboxCapacity = capacity;
	}
	
	//Set the alternate email
	public void setAlternateEmail(String altemail) {
		this.alternateEmail = altemail;
	}
	
	
	//Change the password 
	public void changePassword(String password) {
		this.password = password;
	}
	
	
	public int getMailboxCapacity()
	{
		return mailboxCapacity;
	}
	
	public String getAlternateEmail() {
		return alternateEmail;
	}
	
	public String getPassword() {
		return password;
	}
	
	public String ShowInfo() {
		return "\nDisplay Name:: " + firstName + " " + lastName + 
				"\nYour Email ID Is:: " + email +
				"\nMailboxCapacity Is::" + mailboxCapacity + "mb";
	}
	
	
	
}